# Intelligent Fire Alarm Systems iO64, iO1000  

# Overview  

EDWARDS brand intelligent life safety systems offer the power of high-end intelligent processing in configurations that deliver uncomplicated solutions for small to mid-sized applications. With intelligent detection, electronic addressing, automatic device mapping, optional Ethernet connectivity, and a full line of easilyconfigured option cards and modules, these flexible systems offer versatility that benefits building owners and contractors alike.  

The iO64 provides one Class A or Class B intelligent device loop that supports up to 64 device addresses, and two Class B Notification Ap­pliance Circuits (NACs). Optional Class A device wiring is available with the use of a module.  

The iO1000 provides one Class A or Class B intelligent device loop that supports up to 250 device addresses. Loop controller modules may be added in combination to expand total system capacity in 250-point increments to up to 1,000 device addresses. The iO1000 panel includes four NACs that may be wired for either Class A or Class B operation.  

The RZI16-2 module adds even more capacity to iO installations by adding up to 16 conventional device circuits and two additional notification appliance circuits. This makes them an ideal retrofit solution that can accommodate new intelligent detectors, as well as existing conventional devices.  

iO Series supports a wide range of high-end features, including:  

•	 Supports 10-Year Carbon Monoxide detectors   
•	 R-Series remote annunciators   
•	 SIGA-REL Releasing Modules   
•	 Fully integrated CO detection using Signature Series detectors with or without audible signaling  

# Features  

Auto-programming reduces installation time   
Supports Signature Series intelligent modules and detectors Combines the Signature intelligent releasing module with Signature multisensor detectors for reliable fire suppression   
Form C contacts for alarm and trouble, Form A for supervisory Electronic addressing with automatic device mapping Optional Ethernet port for diagnostics, programming and a variety of system reports Two programmable switches with LEDs and custom labeling Supports Genesis horn silence over two wires, and UL 1971-compliant strobe synchronization   
Class B or Class A wiring   
Ground fault detection by module Supports up to eight serial annunciators, (LCD, LED-only, and graphic interface) Can use existing wiring for most retrofit applications Upload/download remotely or locally Two-level maintenance alert reporting Pre-alarm and alarm verification by point Adjustable detector sensitivity $4\times20$ character backlit LCD display Optional earthquake hardening: seismic Importance Factor 1.5   
Standalone operation   
•Alarm ON command manually activates alarm condition  

# Application  

EDWARDS iO Series life safety systems are powerful intelligent solutions for small to mid-sized buildings. Advanced intelligent technology delivers the benefits of flexible system installation, while clean and easy-to-operate user interfaces make panel operation and system maintenance quick and intuitive.  

# The smart choice  

Signature Series electronic addressing eliminates the tedium of setting dipswitches, and automatic device mapping ensures that each device resides on the system at its correct location. Meanwhile, innovative programming allows the designer to customize the system to precisely suit the needs of the building owner.  

# Reliability you can count on  

The inherent fault-tolerant characteristics of Analog/Addressable Technology boosts the reliability of EDWARDS fire alarm systems. When combined with iO Series smoke and heat detectors, these systems deliver a level of dependability not previously available for small to mid-sized applications. All EDWARDS systems are built to exacting reliability benchmarks.  

# Clear-cut remote annunciation  

Remote annunciation is a strong suit of the iO Series fire alarm systems. Up to eight annunciators can be installed on a single system. Compatible annunciators include a range of LED and LCD models that provide zone or point annunciation, as well as common control capabilities. iO control panels also supports graphic annunciation with optional RA Graphic Annunciator nterface modules. Each interface provides common control and 32 LEDs.  

# Flexibility built right in  

Two fully-programmable front panel switch/LED combinations provide an added measure of flexibility. Their slide-in labels take the mystery out of custom applications, and present a clean finished appearance.  

# Programming and remote diagnostics  

EDWARDS iO Series life safety systems are simple to set up, yet offer advanced programming features that put these small building panels into a class of their own. The auto programming feature quickly gets the panel operational using factory default settings. Basic zone and point settings can be programmed through the front panel interface, so the system is up and running in no time.  

For more advanced system configuration and correlation groups programming, iO Series systems interface to a PC running compatible iO-CU software. This option offers full system configuration in the familiar Windows operating environment. Connection is made to a laptop through the panel’s optional RS-232 communications port, which can also be used to connect a system printer.  

Among the many innovative features of iO Series control panels is the optional network card. This module provides a standard 10/100 Base T Ethernet® network connection that permits access to the control panel from any remote location with the correct communications protocols. The connection can be used to download to the panel from the iO-CU, or upload and view system reports using the iO-CU.  

Available system reports include: Correlation groups, Device details, Device maintenance, History, Internal status, System configuration, System status, Walk test, Dialer, and CO runtime.  

# Perfect for retrofits  

EDWARDS iO Series control panels are particularly well-suited to retrofit applications. All connections are made over standard wiring – no shielded cable required. This means that in most situations existing wiring can be used to upgrade a legacy control panel to iO technology without the expense or disruption of rewiring the entire building. iO control panels also support the ingenious RZI16-2 Zone Module, which adds up to 16 conventional circuits and two NACs. This combination easily accommodates new intelligent detection alongside existing conventional circuits, making it an superior solution in the retrofit market.  

# Scalable IP and Cellular Communications  

Several popular third-party IP/Cellular communicators have been tested with the iO control panels and are compatibility listed to UL864. The IP/Cellular communicators meet NFPA72 2013 edition requirements for sole or secondary transmission paths. Using IP/ Cellular communicators can reduce the cost of ownership by eliminating POTS lines. Please see the iO control panel compatibility documentation part number 3102353-EN for a full list of compatible communicators.  

# Signals with a difference  

iO system NACs are configurable to fully support the advanced signaling technology of EDWARDS Genesis and Enhanced Integrity notification appliances. These devices offer precision synchronization of strobes to UL 1971 standards. For Genesis devices, enabling this feature allows horns to be silenced while strobes on the same two-wire circuit continue to flash until the panel is reset.  

# A complete line of accessories  

iO Series life safety systems are supported by a complete line of analog/addressable detectors, modules and related equipment. Consult the Ordering Information section for details.  

# Dimensions  

![](images/8833096100a1ca0eed47ed64ab1526fd49dd25be0c50dfdb98e6cb93aa3d3540.jpg)  
ce Mounting Holes (3) Backbox with Door Attached flush mounting Holes (4) Backbox with door and trim kit attached.  

Panel dimensions, in (cm)   

![](images/e10e3d3960d27929721f7e3944a538015ac8651f84942ff48ec680575e757092.jpg)  

\* Add 1-1/2 in. $(3.81\;\mathsf{c m})$ to D1 and D5 dimensions for trim kit. The trim kit provides 0.75 inches $\left(1.9\,\mathsf{c m}\right)$ ) of trim to the top, bottom, and sides of the backbox.  

# System Layout  

![](images/8d5255723b9cb7fa661c31c7b439d39c5a3ed9211ac2d991464931c594a25398.jpg)  
iO1000   
Any combination of two single- or dual Signature loop modules  

Each iO1000 panel has room for up to two Signature loop controller modules in any combination of single or dual 250-device loops.  

# Panel Layout  

![](images/574e8444568bc1591ae3da3cf15bec75b41fe827268d3f3bfb200877ecc977f3.jpg)  

be expanded.  

# Signature device loop  

The system provides one Signature device loop circuit with a total capacity of 125 detectors and 125 module addresses. The loop circuit is supervised for opens, shorts, and grounds.  

![](images/c58688096d1a3b8fe313a48036dcfb291671d67013b018fd1238ce4f253e21e1.jpg)  

![](images/023f1b19d86e0083f4e3f72b14fb1b7d455a34569f1063552c20f5b4187be3e1.jpg)  

# Notification appliance circuits (TB2)  

iO1000 control panels come equipped with four notification appliance circuits. iO64 control panels come with two NACs. Each circuit can be individually configured for continuous, temporal, synchronized, and coded output.  

![](images/01ca363e641856781a1da5e8b5bdaadd8e06c3ccfaf0388ae895cc14ab7b0628.jpg)  

![](images/8a71bb77e286553817f655bf287689039ce191b69cd030bf06318d00bd4a4305.jpg)  
Marking indicates output signal polarity when the circuit is active. Polarity reverses when the circuit is not active. Wire notification appliances accordingly. Notification appliance polarity shown in active state.  

# Auxiliary & smoke power outputs (TB3)  

![](images/f2b2c283f6f383463b041b6200215989c6bdaa978b897d13ab9889d215527aef.jpg)  

Relay specifications   

![](images/7c7dda7f7b4f237d5a672b9ffbcaaa53661678cca3cb386598a1149ae26b7164.jpg)  

Relay circuits can only be connected to power-limited sources.  

# Annunciator loop (TB4)  

The control panel provides a connection for up to eight serially driven and supervised remote annunciators.  

Circuit specifications   

![](images/98717bc10230f777a3a9fe4cdf8f45c2fc16e76669f520f067b56d5a279edd69.jpg)  

![](images/b81a3d71d05aff78cb2dd5a110e7136f7087767e6d38f0b1b3768da2b6c80fc6.jpg)  

EDWARDS iO Series panels are supported by a complete line of modules and related equipment that enhance performance and extend system capabilities. Option cards plug directly into the control panel main circuit board or are connected to it with a ribbon cable. After installation, terminals remain accessible. The cabinet provides ample room for wire routing, keeping wiring neat at all times.  

# Single and Dual Loop Controller Cards  

The iO-SDC1 is a single loop controller card that can be used with the iO64 as a replacement for the standard 64-point loop, or with the iO1000 as a 250-point expansion module.  

The iO-SDC2 is a 500-point dual loop controller card for the iO1000 that provides two SLC circuits, each with 125 detector addresses and 125 module addresses.  

![](images/63f2799b2adeb372f75344c80dbf58b66556e20a7bc601682cc05d7ecb7f53ee.jpg)  

# SA-ETH Ethernet Interface Card  

![](images/554c249a40269e05e7b37832c82316f72b62382bd0ad8ed6fa06d5e67383dccd.jpg)  

![](images/7c5b54e04d02b15373e01fce7415242d3d97b1786259088a1123897fdbdec2a7.jpg)  

# RZI16-2 Remote Zone Interface Module  

![](images/33bc439375446d932b950393a1ead991bf2bc17b4bbfa7e08f31893db1483774.jpg)  

The RZI16-2 Addressable Remote Zone Interface Module is an addressable device that provides connections for sixteen Class B Initiating Device Circuits and two Class B Supervised Output Circuits. The inputs and outputs can be configured individually for several device types.  

It requires 18 consecutive addresses on the Signaling Line Circuit (SLC). Addresses are assigned electronically. There are no address switches to set.  

The RZI16-2 incorporates two 8-segment DIP switches that are used to select the Alarm or Supervisory default device type for each of the 16 IDC circuits. The module also includes one 4-segment DIP switch used to select the default Relay or NAC output device type. Device types other than the default are accomplished through programming.  

![](images/62ad9c1ccb2f8af28a0e2df14f3f7106b6575fb90734202b34f22b2274226928.jpg)  

# SA-DACT Dialer  

The SA-DACT provides communications between the control panel and the central station over a telephone line system. It transmits system status changes (events) to a compatible digital alarm communicator receiver over the public switched telephone network. The dialer is capable of single, dual, or split reporting of events to two different account and telephone numbers. The modem feature of the SA-DACT can also be used for uploading and downloading panel configuration, history, and current status to a PC running the iO-CU.  

# SA-232 RS-232 interface  

The SA-232 card provides an RS-232 interface with iO panels. It can be used for connecting a printer to the control panel to print system events. The card also can be used for connecting a computer to download a configuration program from the iO-CU to the control panel.  

![](images/2716be1587a5cbb5851068d320482e5fea184a798e76cf71079d7f7978249d45.jpg)  
The dialer phone lines connect to connectors on the dialer’s main circuit board. Phone line 1 connects to connector J4 and phone line 2 connects to connector J1.  

The RS-232 card is installed on the plastic assembly and connects to the main circuit board via a ribbon cable.  

![](images/cb717d860115518c83889d72cf1c4f7cc4e5f781e884492a80cb42468a5547fc.jpg)  

#  

sages and transmits them based on priority (alarm, supervisory, trouble, and monitor). Activations are transmitted before restorations.  

The SA-DACT is installed on the plastic assembly and connects to the main circuit board via a ribbon cable.  

![](images/0096c16fe529296dfd3b1481af756e6793ce6839883330b7c18d9bc12f331e82.jpg)  

![](images/64f89a76c0a002a9b1eb2a8a2bcd5298f553476a015a7c808de90e27c0f16e80.jpg)  

![](images/0c14f6ee4dfb18f15114183978fa47fcfaaa4fdea34f2e147817adf9af2d89d3.jpg)  

# SA-CLA Class A Module (iO64 only)  

The SA-CLA card provides Class A capability for NAC wiring. Its terminal block provides the wiring connection for NAC return wiring. The card is required for annunciator Class A wiring even though this wiring does not return to the SA-CLA card. The SACLA is compatible with iO64 control panels only. iO1000 panels are Class A Ready. The SA-CLA is installed directly to the control panel circuit board using its plastic standoffs and plug connection.  

SA-CLA specifications   

![](images/f6bf674f65d469eecd3f4b79e3d303e796b5f6205021210bc13eabed0c87ed26.jpg)  

# D16L-iO LED Display Expander (iO1000 only)  

The D16L-iO LED Display Expanders provide LED annunciation for up to 16 zones. It provides two LEDs for each zone. Two D16L-iO LED display expanders can be installed in each iO1000 panel.  

![](images/b1133d19b7d4da200461d425f6cc98d3cc1f7722870062b598e2857c38040fd0.jpg)  

![](images/78cd0735b6b3cb96a0e318b211a839485530817339c62cf044ae83969936d07d.jpg)  

# Ordering Information  

Part Description   
iO1000 Fire Alarm Systems   

![](images/781ad23ff4b44a3c4054cf26c6e474120eb824b1abb5a68bb54e78044dc66128.jpg)  

iO64 Fire Alarm Systems   

![](images/71c72322943e5b15d2a704730370b742178d8ae48747ea07f6cbdc9a23482e3f.jpg)  

![](images/ec2b629b5ede40a4694daa95a5d4936cef96230ae1d110a3179060f19fc0d9e1.jpg)  

![](images/b048c195cbbb94c1f78f12083f6169c3a012ba83fd68b22db2910b779b4b73ed.jpg)  